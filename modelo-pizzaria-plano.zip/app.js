/* Aplica a configuração do cliente (config.js) na página */
document.title=SITE.nome;
document.querySelector('header b').textContent=SITE.emoji+' '+SITE.nome;
document.querySelector('.hero h1').textContent=SITE.titulo;
document.querySelector('.hero p').textContent=SITE.sub;
document.getElementById('rodape').textContent=SITE.nome+' — pedidos pelo WhatsApp';
document.documentElement.style.setProperty('--acc',SITE.cor);

const sv=()=>{try{localStorage.setItem('db',JSON.stringify({CFG,BAIRROS,MENU,CUP}))}catch(e){}};
try{const s=JSON.parse(localStorage.getItem('db'));if(s){Object.assign(CFG,s.CFG);BAIRROS=s.BAIRROS;MENU=s.MENU;CUP=s.CUP}}catch(e){}
const $=s=>document.querySelector(s),R$=v=>'R$'+v.toFixed(2).replace('.',',');
const cart={};
const mins=h=>{const[a,b]=h.split(':');return +a*60+ +b};
function aberto(){const d=new Date(),m=d.getHours()*60+d.getMinutes();return m>=mins(CFG.abre)&&m<mins(CFG.fecha)}
function status(){const s=$('#st');s.textContent=CFG.pausado?'⏸ PAUSADO':aberto()?'🟢 ABERTO':'🔴 FECHADO · abre '+CFG.abre}
status();setInterval(status,30000);
/* cardápio */
function drawMenu(){let h='',c='';MENU.forEach(i=>{if(i.c!==c){c=i.c;h+=`<h3>${c}</h3>`}
h+=`<div class="it ${i.on?'':'off'}"><div><b>${i.n}</b><small>${i.on?i.d:'🔴 Indisponível no momento'}</small><span class="sans">${R$(i.p)}</span></div>${i.on?`<div class="q"><button aria-label="Remover ${i.n}" data-m="${i.id}">−</button><b>${cart[i.id]||0}</b><button aria-label="Adicionar ${i.n}" data-a="${i.id}">+</button></div>`:''}</div>`});
$('#menu').innerHTML=h}
document.addEventListener('click',e=>{const a=e.target.dataset.a,m=e.target.dataset.m,x=e.target.dataset.x;
if(a)cart[a]=(cart[a]||0)+1;else if(m){cart[m]=Math.max(0,(cart[m]||0)-1);if(!cart[m])delete cart[m]}else if(x){for(const k in cart)delete cart[k]}else return;drawMenu();calc()});
function fillB(){const v=$('#bairro').value;$('#bairro').innerHTML=Object.entries(BAIRROS).map(([b,t])=>`<option value="${b}">${b}${t==null?'':' — taxa '+R$(t)}</option>`).join('');if(BAIRROS[v]!==undefined)$('#bairro').value=v}fillB();
['tipo','bairro','pag','cupom'].forEach(i=>$('#'+i).addEventListener('input',calc));
function cupom(){const c=$('#cupom').value.trim().toUpperCase(),o=CUP.find(x=>x.c===c);if(!o||(o.val&&new Date(o.val+'T23:59:59')<new Date())||(o.lim&&o.uso>=o.lim))return null;return o}
function tot(){const it=Object.keys(cart).map(id=>{const m=MENU.find(m=>m.id==id);return m&&m.on?{...m,q:cart[id]}:null}).filter(Boolean);const sub=it.reduce((s,i)=>s+i.p*i.q,0);
const ent=$('#tipo').value==='Entrega',taxa=ent?(BAIRROS[$('#bairro').value]||0):0;
const cp=cupom(),desc=cp?sub*cp.pct/100:0;return{cp,it,sub,taxa,desc,total:sub+taxa-desc,ent}}
function calc(){const t=tot();$('#end').hidden=!t.ent;$('#trocoB').hidden=$('#pag').value!=='Dinheiro';
$('#cart').innerHTML=t.it.length?t.it.map(i=>`<div class="row"><span>${i.q}x ${i.n}</span><span>${R$(i.p*i.q)}</span></div>`).join('')+`<p style="margin:10px 0 0"><button class="btn" style="padding:8px 14px;font-size:14px;background:var(--mut)" data-x="1">Limpar carrinho</button></p>`:'<span style="color:var(--mut)">Seu carrinho está vazio.</span>';
$('#sum').innerHTML=`<div class="row"><span>Subtotal</span><span>${R$(t.sub)}</span></div>`+(t.ent?`<div class="row"><span>Taxa de entrega</span><span>${R$(t.taxa)}</span></div><div class="row"><span>🛵 Entrega estimada</span><span>${CFG.tempo}</span></div>`:'')+(t.desc?`<div class="row"><span>Desconto</span><span>−${R$(t.desc)}</span></div>`:'')+`<div class="row tot"><span>TOTAL</span><span>${R$(t.total)}</span></div>`}
$('#send').onclick=()=>{const t=tot(),m=$('#msg'),err=s=>m.textContent=s;
if(CFG.pausado)return err('🔴 '+CFG.motivo);if(!aberto())return err('🔴 Fechado agora. Abrimos às '+CFG.abre+'.');
if(!t.it.length)return err('Adicione ao menos um item.');if(t.sub<CFG.minimo)return err('Pedido mínimo: '+R$(CFG.minimo));if(!$('#nome').value.trim()||!$('#tel').value.trim())return err('Informe nome e telefone.');
const b=$('#bairro').value;if(t.ent){if(BAIRROS[b]==null)return err('Ainda não entregamos nesse bairro. Escolha retirada.');if(!$('#rua').value.trim()||!$('#num').value.trim())return err('Informe rua e número.')}
let n=1047;try{n=+(localStorage.getItem('pedido_n')||1046)+1;localStorage.setItem('pedido_n',n);const l=JSON.parse(localStorage.getItem('pedidos')||'[]');const d=new Date();
l.push({ts:Date.now(),id_pedido:n,data:d.toISOString().slice(0,10),hora:d.getHours(),dia_semana:d.getDay(),cliente:$('#nome').value,telefone:$('#tel').value,itens:t.it.map(i=>({n:i.n,q:i.q,p:i.p})),subtotal:t.sub,taxa_entrega:t.taxa,desconto:t.desc,total:t.total,forma_pagamento:$('#pag').value,bairro:t.ent?b:'',endereco:t.ent?$('#rua').value+', '+$('#num').value:'',tipo_entrega:$('#tipo').value,status:'Pedido recebido'});localStorage.setItem('pedidos',JSON.stringify(l))}catch(e){}
if(t.cp){t.cp.uso++;sv()}const pg=$('#pag').value+($('#pag').value==='Dinheiro'&&$('#troco').value?' (troco p/ '+$('#troco').value+')':'');
const txt=`🍕 NOVO PEDIDO #${n}\n\n👤 ${$('#nome').value} — ${$('#tel').value}\n\n`+t.it.map(i=>`${i.q}x ${i.n} — ${R$(i.p*i.q)}`).join('\n')+(t.ent?`\n\n📍 ${b}\n🏠 ${$('#rua').value}, ${$('#num').value} ${$('#comp').value}\n🚚 Entrega ${R$(t.taxa)}`:'\n\n🏪 Retirada no local')+`\n💳 ${pg}`+(t.desc?`\n🎟️ Desconto ${R$(t.desc)}`:'')+($('#obs').value?`\n📝 ${$('#obs').value}`:'')+`\n\nTOTAL: ${R$(t.total)}`;
window.open('https://wa.me/'+CFG.wa+'?text='+encodeURIComponent(txt),'_blank');m.textContent='✅ Pedido #'+n+' gerado! Confirme o envio no WhatsApp.'};
drawMenu();calc();

const hv=$('#hv');hv.play&&hv.play().catch(()=>{});$('#cap').textContent=SITE.legenda;

/* ===== PAINEL: Fases 3, 4 e 5 ===== */
let ok=false,tab='pedidos',dias=7,inat=30;
const STS=['Pedido recebido','Em preparação','Pronto','Saiu para entrega','Entregue','Cancelado'],DAY=864e5,DIA=['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
const ref=()=>{const cs=[...new Set(MENU.map(m=>m.c))];MENU.sort((a,b)=>cs.indexOf(a.c)-cs.indexOf(b.c));sv();drawMenu();fillB();calc();status();adm()};
const L=()=>{try{return JSON.parse(localStorage.getItem('pedidos')||'[]').map(o=>({...o,ts:o.ts||Date.parse(o.data)}))}catch(e){return[]}};
const V=()=>L().filter(o=>o.status!=='Cancelado'),d0=()=>{const d=new Date();d.setHours(0,0,0,0);return +d};
const sm=(a,b)=>{const o=V().filter(x=>x.ts>=a&&x.ts<b);return{n:o.length,f:o.reduce((s,x)=>s+x.total,0)}};
const pc=(a,b)=>b?(a>=b?'+':'')+((a-b)/b*100).toFixed(0)+'%':'—';
const bar=(l,v,m,t)=>`<div class="br"><span>${l}</span><i style="width:${m?v/m*55:0}%"></i><b>${t||v}</b></div>`;
const tp=(o,n)=>Object.entries(o).sort((a,b)=>b[1]-a[1]).slice(0,n);
function st(id,v){const l=L(),x=l.find(o=>o.id_pedido==id);if(x){x.status=v;try{localStorage.setItem('pedidos',JSON.stringify(l))}catch(e){}}adm()}
function clientes(){const m={};V().forEach(o=>{const c=m[o.telefone]||(m[o.telefone]={nome:o.cliente,tel:o.telefone,n:0,g:0,u:0,p:{}});c.n++;c.g+=o.total;c.u=Math.max(c.u,o.ts);o.itens.forEach(i=>c.p[i.n]=(c.p[i.n]||0)+i.q)});
return Object.values(m).map(c=>({...c,dias:Math.floor((Date.now()-c.u)/DAY),fav:(tp(c.p,1)[0]||['—'])[0]})).sort((a,b)=>b.g-a.g)}
$('#ab').onclick=()=>{$('#adm').hidden=false;adm()};
function adm(){const p=$('#am');if(!ok){p.innerHTML=`<label for="pin">PIN do painel (padrão 1234)</label><input id="pin" type="password" inputmode="numeric"><p><button class="btn" onclick="if($('#pin').value===CFG.pin){ok=true;adm()}else this.textContent='PIN incorreto'">Entrar</button></p>`;return}
const T=[['pedidos','Pedidos'],['analise','Análises'],['clientes','Clientes'],['config','Config']];
p.innerHTML=`<div class="tb">${T.map(([k,n])=>`<button class="${tab===k?'on':''}" onclick="tab='${k}';adm()">${n}</button>`).join('')}</div>`+({pedidos:tPed,analise:tAna,clientes:tCli,config:tCfg}[tab])()}
function tPed(){const o=L(),n=Date.now(),t0=d0(),al=[],off=MENU.filter(m=>!m.on).length,w=o.filter(x=>x.status==='Pedido recebido').length,lt=o.filter(x=>!['Entregue','Cancelado'].includes(x.status)&&n-x.ts>36e5).length,hj=sm(t0,t0+DAY).n,md=sm(t0-7*DAY,t0).n/7,ni=clientes().filter(c=>c.dias>=30).length;
if(CFG.pausado)al.push('⏸ Sistema pausado');if(off)al.push(`🔴 ${off} produto(s) indisponível(is)`);if(w)al.push(`⏳ ${w} pedido(s) aguardando`);if(lt)al.push(`⏰ ${lt} pedido(s) atrasado(s) (mais de 1h)`);
if(o.filter(x=>n-x.ts<36e5).length>=5)al.push('🔥 Muitos pedidos simultâneos');if(hj>=3&&hj>md*1.3)al.push('📈 Movimento acima da média');if(ni)al.push(`👥 ${ni} cliente(s) inativo(s)`);if(CFG.wa==='5500000000000')al.push('⚙️ Falta configurar o WhatsApp');
return `<h3>🚨 Central de alertas</h3>`+(al.map(a=>`<div class="row">${a}</div>`).join('')||'<div class="row">✅ Tudo em ordem.</div>')+`<h3>Pedidos recentes</h3>`+(o.slice(-20).reverse().map(x=>`<div class="it"><div><b>#${x.id_pedido}</b> ${esc(x.cliente)} · ${R$(x.total)}<small>${x.tipo_entrega}${x.bairro?' · '+esc(x.bairro):''} · ${x.forma_pagamento} · ${new Date(x.ts).toLocaleString('pt-BR')}</small></div><select style="width:auto" onchange="st(${x.id_pedido},this.value)">${STS.map(s=>`<option ${s===x.status?'selected':''}>${s}</option>`).join('')}</select></div>`).join('')||'<p>Nenhum pedido ainda.</p>')}
function tAna(){const t0=d0(),h=sm(t0,t0+DAY),ont=sm(t0-DAY,t0),s7=sm(t0-6*DAY,t0+DAY),s7p=sm(t0-13*DAY,t0-6*DAY),m30=sm(t0-29*DAY,t0+DAY),m30p=sm(t0-59*DAY,t0-29*DAY),rg=V().filter(o=>o.ts>=t0-(dias-1)*DAY),tk=x=>x.n?R$(x.f/x.n):'—',per=dias===1?'hoje':'nos últimos '+dias+' dias';
const cmp=(l,a,b)=>`<div class="row"><span>${l}</span><span>${a.n} × ${b.n} pedidos (${pc(a.n,b.n)}) · ${R$(a.f)} (${pc(a.f,b.f)})</span></div>`;
const hr=Array(24).fill(0),wd=Array(7).fill(0),pq={},pf={},bq={},bf={},bt={},pg={};
rg.forEach(o=>{hr[new Date(o.ts).getHours()]++;wd[new Date(o.ts).getDay()]++;o.itens.forEach(i=>{pq[i.n]=(pq[i.n]||0)+i.q;pf[i.n]=(pf[i.n]||0)+i.q*i.p});const b=o.bairro||'Retirada';bq[b]=(bq[b]||0)+1;bf[b]=(bf[b]||0)+o.total;bt[b]=(bt[b]||0)+(o.taxa_entrega||0);pg[o.forma_pagamento]=(pg[o.forma_pagamento]||0)+1});
const mh=Math.max(...hr),pk=hr.indexOf(mh),lo=hr.findIndex(x=>x),hi=23-[...hr].reverse().findIndex(x=>x),mw=Math.max(...wd),mq=Math.max(0,...Object.values(pq)),mb=Math.max(0,...Object.values(bq));
const pz=MENU.filter(m=>m.c!=='Adicionais e bordas'),ad=MENU.filter(m=>m.c==='Adicionais e bordas').sort((a,b)=>(pq[b.n]||0)-(pq[a.n]||0))[0],low=[...pz].sort((a,b)=>(pq[a.n]||0)-(pq[b.n]||0)).slice(0,3),cl=clientes().filter(c=>c.dias>=30).length,I=[];
if(mh)I.push(`🔥 Seu maior movimento está entre ${pk}h e ${pk+1}h.`);const t1=tp(pq,1)[0];if(t1)I.push(`🍕 ${t1[0]} representa ${(t1[1]/Object.values(pq).reduce((a,b)=>a+b,0)*100).toFixed(0)}% dos itens vendidos.`);const b1=tp(bq,1)[0];if(b1)I.push(`📍 ${b1[0]} é a região com maior volume.`);if(cl)I.push(`👥 ${cl} cliente(s) que já compraram estão há 30+ dias sem pedir.`);if(s7p.n)I.push(s7.n>=s7p.n?'📈 O volume desta semana está acima do período anterior.':'📉 O volume desta semana está abaixo do período anterior.');
return `<div class="cd"><div>Hoje<b>${h.n}</b>${R$(h.f)}</div><div>7 dias<b>${s7.n}</b>${R$(s7.f)}</div><div>30 dias<b>${m30.n}</b>${R$(m30.f)}</div></div><div class="row" style="margin-top:8px"><span>Ticket médio (30 dias)</span><b>${tk(m30)}</b></div>
<h3>🧠 Inteligência</h3>${I.map(x=>`<div class="row">${x}</div>`).join('')||'<div class="row">Os insights aparecem conforme os pedidos entram.</div>'}
<h3>📈 Comparações</h3>${cmp('Hoje × ontem',h,ont)}${cmp('7 dias × anteriores',s7,s7p)}${cmp('30 dias × anteriores',m30,m30p)}
<label>Período das análises abaixo</label><select onchange="dias=+this.value;adm()">${[1,7,30].map(d=>`<option value="${d}" ${d===dias?'selected':''}>${d===1?'Hoje':d+' dias'}</option>`).join('')}</select>
<h3>⏰ Horário de pico</h3>${mh?hr.slice(lo,hi+1).map((v,i)=>bar((lo+i)+'h–'+(lo+i+1)+'h',v,mh,v+(v===mh?' 🔥':''))).join('')+`<p>🔥 Maior movimento: ${pk}h–${pk+1}h</p>`:'<p>Sem pedidos no período.</p>'}
<h3>📅 Dia da semana</h3>${mw?wd.map((v,i)=>bar(DIA[i].slice(0,3),v,mw)).join('')+`<p>📊 Maior volume ${per}: ${DIA[wd.indexOf(mw)].toLowerCase()}. Com poucos dados isso ainda não é regra.</p>`:'<p>Sem dados.</p>'}
<h3>🍕 Produtos</h3>${tp(pq,5).map(([n,q])=>bar(esc(n),q,mq,q+' · '+R$(pf[n]))).join('')||'<p>Sem vendas.</p>'}<p>💡 Baixa saída (avaliar promoção): ${low.map(m=>esc(m.n)+' ('+(pq[m.n]||0)+')').join(', ')||'—'}</p>${ad?`<p>Adicional mais vendido: ${esc(ad.n)} (${pq[ad.n]||0})</p>`:''}
<h3>🏘️ Bairros</h3>${tp(bq,6).map(([b,n])=>bar(esc(b),n,mb,n+' · '+R$(bf[b])+' · taxas '+R$(bt[b]))).join('')||'<p>Sem dados.</p>'}<p>Pouco usados: ${Object.keys(BAIRROS).filter(b=>BAIRROS[b]!=null&&!bq[b]).map(esc).join(', ')||'—'}</p>
<h3>💳 Pagamento mais usado</h3><p>${tp(pg,1)[0]?tp(pg,1)[0][0]+' ('+tp(pg,1)[0][1]+' pedidos)':'—'}</p>`}
function tCli(){const cs=clientes(),ia=cs.filter(c=>c.dias>=inat);
return `<h3>👤 Clientes (${cs.length})</h3>`+(cs.map(c=>`<div class="it"><div><b>${esc(c.nome)}</b>${c.n>=3?' ⭐ recorrente':''}<small>${esc(c.tel)} · ${c.n} pedidos · ${R$(c.g)} · último há ${c.dias} dia(s) · favorito: ${esc(c.fav)}</small></div></div>`).join('')||'<p>Nenhum cliente ainda.</p>')+`<h3>🔔 Clientes que sumiram</h3><label for="inat">Sem comprar há (dias)</label><input id="inat" type="number" value="${inat}" onchange="inat=+this.value||30;adm()">`+(ia.map(c=>`<div class="it"><div><b>${esc(c.nome)}</b><small>${c.n} pedidos · ${R$(c.g)} gastos · último pedido há ${c.dias} dias</small></div><a class="btn" style="padding:8px 12px;font-size:14px" target="_blank" href="https://wa.me/55${c.tel.replace(/\D/g,'')}?text=${encodeURIComponent('Oi '+c.nome.split(' ')[0]+'! Faz um tempinho que você não pede sua pizza aqui na '+SITE.nome+' 🍕 Volte com o cupom '+(CUP[0]?CUP[0].c:'')+'.')}">WhatsApp</a></div>`).join('')||'<p>Nenhum cliente inativo.</p>')}
function tCfg(){const cats=[...new Set(MENU.map(m=>m.c))];
return `<h3>Operação</h3><label class="ck"><input type="checkbox" ${CFG.pausado?'checked':''} onchange="CFG.pausado=this.checked;ref()"> Pausar pedidos</label>
<label>Mensagem quando pausado</label><input value="${esc(CFG.motivo)}" onchange="CFG.motivo=this.value;sv()">
<label>Abre</label><input type="time" value="${CFG.abre}" onchange="CFG.abre=this.value;ref()"><label>Fecha</label><input type="time" value="${CFG.fecha}" onchange="CFG.fecha=this.value;ref()">
<label>Tempo estimado de entrega</label><input value="${esc(CFG.tempo)}" onchange="CFG.tempo=this.value;ref()"><label>Pedido mínimo (R$)</label><input type="number" value="${CFG.minimo}" onchange="CFG.minimo=+this.value;ref()">
<label>WhatsApp (DDI+DDD+número)</label><input value="${CFG.wa}" onchange="CFG.wa=this.value.replace(/\\D/g,'');ref()"><label>PIN do painel</label><input value="${esc(CFG.pin)}" onchange="CFG.pin=this.value;sv()">
<h3>Produtos e disponibilidade</h3>${MENU.map((m,i)=>`<div class="pr"><input value="${esc(m.n)}" onchange="MENU[${i}].n=this.value;ref()"><input type="number" step=".1" value="${m.p}" onchange="MENU[${i}].p=+this.value;ref()"><label class="ck"><input type="checkbox" ${m.on?'checked':''} onchange="MENU[${i}].on=this.checked;ref()">ativo</label><button aria-label="Excluir" onclick="MENU.splice(${i},1);ref()">✕</button></div>`).join('')}
<div class="pr"><input id="nn" placeholder="Novo produto"><input id="np" type="number" step=".1" placeholder="Preço"><select id="nc">${cats.map(c=>`<option>${esc(c)}</option>`).join('')}</select><button aria-label="Adicionar" onclick="if($('#nn').value){MENU.push({id:Date.now(),c:$('#nc').value,n:$('#nn').value,d:'',p:+$('#np').value,on:true});ref()}">＋</button></div>
<h3>Bairros e taxas</h3>${Object.entries(BAIRROS).filter(([b,t])=>t!=null).map(([b,t])=>`<div class="pr"><input value="${esc(b)}" disabled><input type="number" step=".5" value="${t}" onchange="BAIRROS[this.dataset.b]=+this.value;ref()" data-b="${esc(b)}"><button aria-label="Excluir" onclick="delete BAIRROS[this.dataset.b];ref()" data-b="${esc(b)}">✕</button></div>`).join('')}
<div class="pr"><input id="bn" placeholder="Novo bairro"><input id="bt" type="number" step=".5" placeholder="Taxa"><button aria-label="Adicionar" onclick="if($('#bn').value){const n={};Object.entries(BAIRROS).forEach(([k,v])=>{if(v!=null)n[k]=v});n[$('#bn').value]=+$('#bt').value;n['Bairro não atendido']=null;BAIRROS=n;ref()}">＋</button></div>
<h3>Cupons</h3>${CUP.map((c,i)=>`<div class="pr"><input value="${esc(c.c)}" disabled><span>${c.pct}%</span><input type="date" value="${c.val}" title="Validade" onchange="CUP[${i}].val=this.value;sv()"><input type="number" value="${c.lim}" title="Limite de usos (0 = ilimitado)" onchange="CUP[${i}].lim=+this.value;sv()"><button aria-label="Excluir" onclick="CUP.splice(${i},1);ref()">✕</button></div><small>usos: ${c.uso} · validade e limite (0 = ilimitado)</small>`).join('')}
<div class="pr"><input id="cc" placeholder="CÓDIGO"><input id="cp" type="number" placeholder="% desconto"><button aria-label="Adicionar" onclick="if($('#cc').value&&$('#cp').value){CUP.push({c:$('#cc').value.toUpperCase(),pct:+$('#cp').value,val:'',lim:0,uso:0});ref()}">＋</button></div>`}
