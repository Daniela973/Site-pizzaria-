/* ============================================================
   CONFIGURAÇÃO DO CLIENTE — edite só este arquivo para criar
   um site novo. Depois troque hero.mp4 e poster.jpg.
   ============================================================ */
const SITE={
  nome:'Forno & Fumaça',            // nome da pizzaria
  emoji:'🍕',
  titulo:'Pizza feita na hora, saindo fumegante.',  // título do hero
  sub:'Massa artesanal, forno a lenha e entrega quentinha.',
  legenda:'Quentinha, do forno até você.',           // frase sobre o vídeo
  cor:'#c8321a'                     // cor dos botões e destaques
};

/* Operação: wa = DDI+DDD+número, só dígitos (ex.: 5511999998888) */
const CFG={wa:'5500000000000',abre:'11:00',fecha:'23:30',pausado:false,motivo:'Estamos temporariamente sem receber pedidos. Voltaremos em breve.',tempo:'40–55 minutos',pin:'1234',minimo:0};let CUP=[{c:'PIZZA10',pct:10,val:'',lim:0,uso:0}];
let BAIRROS={'Centro':5,'Jardim América':7,'Vila Nova':8,'Bairro não atendido':null};
let MENU=[
{id:1,c:'Pizzas',n:'Calabresa Artesanal',d:'Mussarela, calabresa e cebola',p:58.9,on:true},
{id:2,c:'Pizzas',n:'Margherita',d:'Molho, mussarela, tomate e manjericão',p:52.9,on:true},
{id:3,c:'Pizzas',n:'Quatro Queijos',d:'Mussarela, provolone, gorgonzola e parmesão',p:62.9,on:true},
{id:4,c:'Pizzas',n:'Portuguesa',d:'Presunto, ovo, cebola, azeitona e pimentão',p:60.9,on:false},
{id:5,c:'Adicionais e bordas',n:'Borda de Catupiry',d:'Para qualquer pizza',p:8,on:true},
{id:6,c:'Adicionais e bordas',n:'Borda de Cheddar',d:'Para qualquer pizza',p:8,on:true},
{id:7,c:'Adicionais e bordas',n:'Bacon extra',d:'Porção extra',p:6,on:true},
{id:8,c:'Bebidas',n:'Refrigerante lata',d:'350 ml',p:6,on:true},
{id:9,c:'Bebidas',n:'Refrigerante 2L',d:'Diversos sabores',p:12,on:true},
{id:10,c:'Bebidas',n:'Água mineral',d:'500 ml',p:4,on:true}];
