# Modelo de site para pizzaria

Site de pedidos pelo WhatsApp, com hero em vídeo, carrinho, delivery/retirada, pagamento, aberto/fechado e painel do dono com análises. É um site estático (HTML, CSS e JS): não precisa de build nem de servidor.

## Arquivos
- `config.js` — **tudo que muda de cliente para cliente** (nome, WhatsApp, horários, cardápio, bairros, cupons).
- `hero.mp4` e `poster.jpg` — vídeo do hero e a foto que aparece enquanto ele carrega.
- `index.html`, `style.css`, `app.js` — o site em si. Normalmente você não mexe.

## Criar o site de um novo cliente (cerca de 10 minutos)
1. Duplique este repositório (ou a pasta) e dê o nome do cliente.
2. Abra `config.js` e troque: `SITE` (nome, textos, cor), `CFG` (WhatsApp com DDI+DDD, horário, tempo de entrega, PIN, pedido mínimo), `BAIRROS` (taxas), `MENU` (produtos e preços) e `CUP` (cupons).
3. Troque o vídeo e a foto (mesmos nomes de arquivo) (veja abaixo).
4. Teste no computador: abra `index.html` no navegador, monte um pedido e confira a mensagem no WhatsApp.
5. Publique: envie para o GitHub e importe o repositório na **Vercel** ou **Netlify**. Não precisa de comando de build; a pasta de saída é a raiz.
6. Aponte o domínio do cliente para o site.

## Vídeo do hero
- Vertical, de 3 a 5 segundos, sem áudio, com loop suave (o fim parecido com o começo). Ideal abaixo de 1 MB.
- Se o vídeo for uma gravação de tela, corte a barra do celular e a marca antes de usar.
- Comprimir com ffmpeg:
  `ffmpeg -i entrada.mp4 -an -vf "scale=720:-2,fps=24" -c:v libx264 -crf 25 -preset slow -movflags +faststart hero.mp4`
- Gerar a foto de espera:
  `ffmpeg -i hero.mp4 -frames:v 1 -q:v 4 poster.jpg`

## Painel do dono
Botão ⚙️ no topo. O PIN inicial é `1234` (troque em `config.js`). Tem pedidos com status, alertas, análises, clientes e configurações (pausar pedidos, produtos, bairros, cupons).

## Limites que você precisa explicar ao cliente
- Os pedidos e o painel ficam salvos **no aparelho de quem usa o site**. O dono só vê no painel os pedidos feitos no próprio aparelho. Os pedidos de todos os clientes chegam pelo **WhatsApp**.
- O PIN do painel **não é segurança de verdade**, porque roda no navegador.
- Se você editar `config.js` depois de testar no seu navegador, o navegador pode mostrar os dados antigos. Limpe os dados do site ou use uma aba anônima.
- Para salvar pedidos de todos os clientes em um só lugar, com login de verdade, é preciso um banco de dados (por exemplo o Supabase). Esse é o pacote avançado.

## Antes de entregar
- [ ] Número de WhatsApp correto e testado.
- [ ] Cardápio, preços, bairros, taxas e horários reais.
- [ ] PIN trocado.
- [ ] Vídeo e fotos com direito de uso comercial (confira as regras da ferramenta usada para gerar) e sem marca d'água indevida.
- [ ] Aviso de privacidade (LGPD), se for guardar dados de clientes.
- [ ] Pedido de teste feito de um celular.
